
// backend/server.js
const express = require('express');
const dotenv = require('dotenv');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

// Load env vars FIRST
dotenv.config({ path: path.resolve(__dirname, '.env') });

// Validate required environment variables before doing anything else
const requiredEnvVars = ['NODE_ENV', 'PORT', 'JWT_SECRET', 'DB_USER', 'DB_PASSWORD', 'DB_HOST', 'DB_PORT', 'DB_NAME'];
const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);

if (missingVars.length > 0) {
  console.error('---------------------------------------------------------------------------');
  console.error(`FATAL ERROR: Missing required environment variables: ${missingVars.join(', ')}`);
  console.error('Please ensure your backend/.env file is complete and correct.');
  console.error('---------------------------------------------------------------------------');
  process.exit(1);
}

// Add a specific, non-fatal warning for the Gemini API Key
if (!process.env.GEMINI_API_KEY) {
  console.warn('---------------------------------------------------------------------------');
  console.warn('WARNING: GEMINI_API_KEY is not set in backend/.env');
  console.warn('The AI Chatbot and AI Insight features will not be available.');
  console.warn('Please get an API key from Google AI Studio and add it to the .env file.');
  console.warn('---------------------------------------------------------------------------');
}

// Add a specific, non-fatal warning for the Email Service
const emailEnvVars = ['EMAIL_HOST', 'EMAIL_PORT', 'EMAIL_USER', 'EMAIL_PASS'];
const missingEmailVars = emailEnvVars.filter(varName => !process.env[varName]);
if (missingEmailVars.length > 0) {
  console.warn('---------------------------------------------------------------------------');
  console.warn(`WARNING: Email service is not fully configured. Missing: ${missingEmailVars.join(', ')}`);
  console.warn('Automated email notifications will be disabled.');
  console.warn('---------------------------------------------------------------------------');
}

const { connectDB } = require('./config/db'); // Import connectDB
const { notFound, errorHandler } = require('./middleware/errorMiddleware');

// Route files
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const assetRoutes = require('./routes/assetRoutes');
const inventoryRoutes = require('./routes/inventoryRoutes');
const asnRoutes = require('./routes/asnRoutes');
const orderRoutes = require('./routes/orderRoutes');
const dispatchRoutes = require('./routes/dispatchRoutes');
const vendorRoutes = require('./routes/vendorRoutes'); 
const reportingRoutes = require('./routes/reportingRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const aiFeedbackRoutes = require('./routes/aiFeedbackRoutes');
const geminiRoutes = require('./routes/geminiRoutes'); // For chatbot
const aiInsightRoutes = require('./routes/aiInsightRoutes'); // For specific insights
const dashboardRoutes = require('./routes/dashboardRoutes'); // Import Dashboard routes
const systemRoutes = require('./routes/systemRoutes');
const eventRoutes = require('./routes/eventRoutes');

const startApp = async () => {
    // 1. Connect to Database first
    await connectDB();

    // 2. Initialize Express App after DB is ready
    const app = express();
    
    // 3. Middleware
    const allowedOrigins = process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : [];

    if (process.env.NODE_ENV === 'development' && allowedOrigins.length === 0) {
      allowedOrigins.push('http://localhost:5173', 'http://localhost:5176', 'http://localhost:3000', 'http://localhost:8000', 'http://127.0.0.1:5500');
    }
    
    const corsOptions = {
      origin: (origin, callback) => {
        if (!origin || allowedOrigins.includes('*') || allowedOrigins.includes(origin)) {
          return callback(null, true);
        }
        return callback(new Error(`The CORS policy for this site does not allow access from the specified Origin: ${origin}`));
      },
      credentials: true,
      optionsSuccessStatus: 200,
    };
    app.use(cors(corsOptions));
    
    app.use(helmet()); 
    if (process.env.NODE_ENV === 'development') {
      app.use(morgan('dev')); 
    }
    app.use(express.json({ limit: '10mb' })); 
    app.use(express.urlencoded({ extended: true })); 
    
    // 4. Rate Limiting
    const generalLimiter = rateLimit({
        windowMs: 15 * 60 * 1000, max: 500, standardHeaders: true, legacyHeaders: false,
        message: 'Too many requests from this IP, please try again after 15 minutes',
    });
    const authLimiter = rateLimit({
        windowMs: 15 * 60 * 1000, max: 50, standardHeaders: true, legacyHeaders: false,
        message: 'Too many login/register attempts from this IP, please try again after 15 minutes',
    });

    // 5. Mount Routes
    const API_PREFIX = '/api/v1';

    // Handle root route requests gracefully by redirecting to the main API endpoint
    app.get('/', (req, res) => {
      res.redirect(API_PREFIX);
    });
    
    app.use(API_PREFIX, generalLimiter);
    app.get(API_PREFIX, (req, res) => res.json({ message: 'Welcome to Vision79 SIWM Backend API! V1' }));
    
    app.use(`${API_PREFIX}/auth`, authLimiter, authRoutes);
    app.use(`${API_PREFIX}/users`, userRoutes);
    app.use(`${API_PREFIX}/assets`, assetRoutes);
    app.use(`${API_PREFIX}/inventory`, inventoryRoutes);
    app.use(`${API_PREFIX}/asns`, asnRoutes);
    app.use(`${API_PREFIX}/orders`, orderRoutes);
    app.use(`${API_PREFIX}/dispatch`, dispatchRoutes);
    app.use(`${API_PREFIX}/vendors`, vendorRoutes); 
    app.use(`${API_PREFIX}/reports`, reportingRoutes);
    app.use(`${API_PREFIX}/notifications`, notificationRoutes);
    app.use(`${API_PREFIX}/ai-feedback`, aiFeedbackRoutes);
    app.use(`${API_PREFIX}/gemini`, geminiRoutes);
    app.use(`${API_PREFIX}/ai-insights`, aiInsightRoutes);
    app.use(`${API_PREFIX}/dashboard`, dashboardRoutes);
    app.use(`${API_PREFIX}/system`, systemRoutes);
    app.use(`${API_PREFIX}/events`, eventRoutes);
    
    // 6. Error Handlers
    app.use(notFound); 
    app.use(errorHandler); 

    // 7. Start Server
    const PORT = process.env.PORT || 3001;

    // --- Port Sanity Check ---
    if (['5432', '3306', '27017', '1433'].includes(String(PORT))) {
        console.warn('---------------------------------------------------------------------------');
        console.warn(`[WARNING] Your application PORT is set to ${PORT}, which is a common database port.`);
        console.warn(`This can cause conflicts. The application server should run on a dedicated port like 4000.`);
        console.warn('---------------------------------------------------------------------------');
    }
    
    app.listen(PORT, () => {
        console.log(`Server is running in ${process.env.NODE_ENV} mode on http://localhost:${PORT}`);
    });
};

// Start the application
startApp().catch(error => {
    console.error("Failed to start the application due to a fatal error:", error);
    process.exit(1);
});
