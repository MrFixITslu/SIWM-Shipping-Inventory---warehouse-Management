




// backend/controllers/asnController.js
const asnService = require('../services/asnService');
const multer = require('multer');
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

const getASNs = async (req, res, next) => {
  try {
    const asns = await asnService.getAllASNs();
    res.json(asns);
  } catch (error) { next(error); }
};

const getASNById = async (req, res, next) => {
  const asnId = parseInt(req.params.id, 10);
  if (isNaN(asnId)) {
    res.status(400); return next(new Error('Invalid ASN ID format. ID must be a number.'));
  }
  try {
    const asn = await asnService.getASNById(asnId);
    if (!asn) { res.status(404); throw new Error('ASN not found'); }
    res.json(asn);
  } catch (error) { next(error); }
};

const createASN = async (req, res, next) => {
  const { 
    supplier, expectedArrival, itemCount, carrier, items, status, poNumber, department, 
    poFileData, poFileName, vendorInvoiceData, vendorInvoiceName, shippingInvoiceData, 
    shippingInvoiceName, billOfLadingData, billOfLadingName, brokerId, brokerName
  } = req.body;
  
  // Basic Input Validation
  if (!poNumber || !supplier || !expectedArrival || (typeof itemCount !== 'number' || itemCount < 0) || !carrier || !brokerId) {
    res.status(400); 
    return next(new Error('P.O. Number, Supplier, Broker, expected arrival, valid non-negative item count, and carrier are required'));
  }

  try {
    const newASN = await asnService.createASN(req.body); // Pass camelCase body directly
    res.status(201).json(newASN);
  } catch (error) { next(error); }
};

const updateASN = async (req, res, next) => {
  const asnId = parseInt(req.params.id, 10);
  if (isNaN(asnId)) {
    res.status(400); return next(new Error('Invalid ASN ID format. ID must be a number.'));
  }
  try {
    if (Object.keys(req.body).length === 0) {
        res.status(400);
        return next(new Error('No update data provided.'));
    }

    const updatedASN = await asnService.updateASN(asnId, req.body); // Pass camelCase body directly
    if (!updatedASN) { res.status(404); throw new Error('ASN not found for update'); }
    res.json(updatedASN);
  } catch (error) { next(error); }
};

const deleteASN = async (req, res, next) => {
  const asnId = parseInt(req.params.id, 10);
  if (isNaN(asnId)) {
    res.status(400); return next(new Error('Invalid ASN ID format. ID must be a number.'));
  }
  try {
    const success = await asnService.deleteASN(asnId);
    if (!success) { res.status(404); throw new Error('ASN not found for deletion'); }
    res.status(204).send();
  } catch (error) { next(error); }
};

const submitFees = async (req, res, next) => {
    const dispatchId = parseInt(req.params.id, 10);
    if (isNaN(dispatchId)) {
        res.status(400); return next(new Error('Invalid ASN ID format.'));
    }
    const { fees } = req.body;
    if (!fees || typeof fees !== 'object') {
        res.status(400); return next(new Error('Fees object is required.'));
    }
    try {
        const updatedAsn = await asnService.submitFees(dispatchId, fees, req.user.id);
        res.json(updatedAsn);
    } catch (error) { next(error); }
};
const approveFees = async (req, res, next) => {
    const dispatchId = parseInt(req.params.id, 10);
    if (isNaN(dispatchId)) {
        res.status(400); return next(new Error('Invalid ASN ID format.'));
    }
    const { feeStatus } = req.body;
     if (!feeStatus || (feeStatus !== 'Approved' && feeStatus !== 'Rejected')) {
        res.status(400); return next(new Error('A valid feeStatus ("Approved" or "Rejected") is required.'));
    }
    try {
        const updatedAsn = await asnService.approveFees(dispatchId, feeStatus, req.user.id);
        res.json(updatedAsn);
    } catch (error) { next(error); }
};

const confirmPayment = async (req, res, next) => {
    upload.single('receipt')(req, res, async (err) => {
        if (err) return next(err);
        const asnId = parseInt(req.params.id, 10);
        if (isNaN(asnId)) {
            res.status(400); return next(new Error('Invalid ASN ID format.'));
        }
        
        try {
            const receiptFile = req.file ? {
                name: req.file.originalname,
                data: req.file.buffer.toString('base64')
            } : null;

            const updatedAsn = await asnService.confirmPayment(asnId, receiptFile, req.user.id);
            res.json(updatedAsn);
        } catch (error) {
            next(error);
        }
    });
};

const receiveShipment = async (req, res, next) => {
    const asnId = parseInt(req.params.id, 10);
    if (isNaN(asnId)) {
        res.status(400); return next(new Error('Invalid ASN ID format.'));
    }
    const { receivedItems } = req.body;
    if (!Array.isArray(receivedItems)) {
        res.status(400); return next(new Error('receivedItems array is required.'));
    }
    try {
        const updatedAsn = await asnService.receiveShipment(asnId, receivedItems, req.user.id);
        res.json(updatedAsn);
    } catch (error) { next(error); }
};

module.exports = { getASNs, getASNById, createASN, updateASN, deleteASN, submitFees, approveFees, confirmPayment, receiveShipment };
