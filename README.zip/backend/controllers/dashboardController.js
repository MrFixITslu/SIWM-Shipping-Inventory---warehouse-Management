// backend/controllers/dashboardController.js
const dashboardServiceBackend = require('../services/dashboardServiceBackend');

const getMetrics = async (req, res, next) => {
    try {
        const metrics = await dashboardServiceBackend.getDashboardMetrics();
        res.json(metrics);
    } catch (error) {
        next(error);
    }
};

const getWorkflowMetrics = async (req, res, next) => {
    try {
        const metrics = await dashboardServiceBackend.getWorkflowMetrics();
        res.json(metrics);
    } catch (error) {
        next(error);
    }
};

const getShipmentsChart = async (req, res, next) => {
    try {
        const chartData = await dashboardServiceBackend.getShipmentChartData();
        res.json(chartData);
    } catch (error) {
        next(error);
    }
};

const getOrderVolumeChart = async (req, res, next) => {
    try {
        const chartData = await dashboardServiceBackend.getOrderVolumeChartData();
        res.json(chartData);
    } catch (error) {
        next(error);
    }
};

const getUnacknowledgedCount = async (req, res, next) => {
    try {
        const count = await dashboardServiceBackend.getUnacknowledgedOrdersCount();
        res.json({ count });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    getMetrics,
    getShipmentsChart,
    getOrderVolumeChart,
    getUnacknowledgedCount,
    getWorkflowMetrics,
};