
// backend/controllers/masterDataController.js
// Placeholder for future master data feature development.
// Current master data (inventory, vendors) is handled by their respective controllers.

const getMasterData = async (req, res, next) => {
  res.json({ message: 'getMasterData endpoint not yet implemented.' });
};

module.exports = {
  getMasterData,
};
