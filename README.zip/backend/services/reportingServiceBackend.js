// backend/services/reportingServiceBackend.js
const { getPool } = require('../config/db');
const { mapToCamel } = require('../utils/dbMappers');

const _applyGenericTextFilter = (data, filters) => {
    if (filters && filters.searchTerm && typeof filters.searchTerm === 'string' && data.length > 0) {
        const searchTermLower = filters.searchTerm.toLowerCase();
        return data.filter(item => 
            Object.values(item).some(val => 
                String(val).toLowerCase().includes(searchTermLower)
            )
        );
    }
    return data;
};

const getReportData = async (reportKey, filters = {}) => {
  const pool = getPool();
  let query = '';
  let queryParams = [];
  let rawData = [];

  switch (reportKey) {
    case 'inv_stock_levels':
      query = 'SELECT sku, name, category, quantity, location, reorder_point, cost_price, is_serialized FROM inventory_items';
      if (filters.category) {
        query += ' WHERE lower(category) = lower($1)';
        queryParams.push(filters.category);
        if (filters.location) {
            query += ' AND lower(location) LIKE $2';
            queryParams.push(`%${filters.location.toLowerCase()}%`);
        }
      } else if (filters.location) {
         query += ' WHERE lower(location) LIKE $1';
         queryParams.push(`%${filters.location.toLowerCase()}%`);
      }
      query += ' ORDER BY name ASC';
      const stockLevelsRes = await pool.query(query, queryParams);
      rawData = mapToCamel(stockLevelsRes.rows).map(item => ({
        ...item,
        reorderPoint: item.isSerialized ? 'N/A' : item.reorderPoint,
      }));
      break;

    case 'inv_serialized_report':
      query = `
        SELECT 
          i.sku, 
          i.name as item_name, 
          unnest(i.serial_numbers) as serial_number, 
          i.location, 
          'In Stock' as status, -- Simplified: real status would be complex
          i.entry_date,
          i.id as item_id 
        FROM inventory_items i 
        WHERE i.is_serialized = TRUE AND i.serial_numbers IS NOT NULL AND array_length(i.serial_numbers, 1) > 0
      `;
      const serialReportConditions = [];
      if (filters.sku) {
        serialReportConditions.push(`lower(i.sku) LIKE $${queryParams.length + 1}`);
        queryParams.push(`%${filters.sku.toLowerCase()}%`);
      }
      if (serialReportConditions.length > 0) {
        query += ' AND ' + serialReportConditions.join(' AND ');
      }
      query += ' ORDER BY i.name, serial_number ASC';
      const serializedRes = await pool.query(query, queryParams);
      rawData = mapToCamel(serializedRes.rows);
      break;

    case 'inv_aging_report':
      query = `
        SELECT 
          sku, 
          name, 
          quantity, 
          entry_date, 
          COALESCE(last_movement_date, entry_date) as last_movement_date,
          (CURRENT_DATE - COALESCE(entry_date, CURRENT_DATE)) as days_in_stock,
          cost_price,
          (quantity * COALESCE(cost_price, 0)) as total_value
        FROM inventory_items
      `;
      if (filters.minDaysInStock && !isNaN(parseInt(filters.minDaysInStock))) {
        query += ' WHERE (CURRENT_DATE - COALESCE(entry_date, CURRENT_DATE)) >= $1';
        queryParams.push(parseInt(filters.minDaysInStock));
      }
      query += ' ORDER BY days_in_stock DESC';
      const agingRes = await pool.query(query, queryParams);
      rawData = mapToCamel(agingRes.rows);
      break;

    case 'ai_stock_out_forecast':
      query = `
        SELECT 
            id as item_id, sku, name as item_name, quantity as current_stock, reorder_point 
        FROM inventory_items 
        WHERE is_serialized = FALSE AND reorder_point > 0 AND quantity < (reorder_point * 1.5)
        ORDER BY (quantity::decimal / reorder_point::decimal) ASC LIMIT 10
      `;
      const forecastCandidates = (await pool.query(query)).rows;
      rawData = mapToCamel(forecastCandidates).map(item => {
          const consumptionRatio = item.currentStock / ((item.reorderPoint * 1.5) || 1); 
          const confidence = 0.8 + (1 - consumptionRatio) * 0.15;
          const predictedStockOutDays = Math.round(consumptionRatio * 14) + 1;
          const recommendedReorderQty = Math.max(0, (item.reorderPoint || 0) * 2 - item.currentStock);
          return {
              itemId: item.itemId,
              sku: item.sku,
              itemName: item.itemName,
              currentStock: item.currentStock,
              predictedStockOutDays,
              confidence: parseFloat(confidence.toFixed(2)),
              recommendedReorderQty: Math.ceil(recommendedReorderQty / 5) * 5,
          };
      });
      break;
      
    case 'vendor_performance':
        query = `
            SELECT 
                id, name, contact_person, email, performance_score,
                average_lead_time, total_spend
            FROM vendors
            ORDER BY performance_score DESC
        `;
        const vendorPerfRes = await pool.query(query);
        rawData = mapToCamel(vendorPerfRes.rows).map(vendor => ({
            ...vendor,
            onTimeDeliveryRate: vendor.performanceScore || 0,
            qualityRating: parseFloat(((vendor.performanceScore || 0) / 20).toFixed(1)),
        }));
        break;

    case 'compliance_document_status':
        query = `
            SELECT 
                cd.name, rs.name as standard_name, cd.status, cd.version, 
                cd.expiry_date, cd.last_reviewed_date, cd.responsible_person 
            FROM compliance_documents cd
            LEFT JOIN regulatory_standards rs ON cd.standard_id = rs.id
            ORDER BY cd.status, cd.expiry_date ASC NULLS LAST
        `;
        const complianceDocsRes = await pool.query(query);
        rawData = mapToCamel(complianceDocsRes.rows);
        break;

    default:
      console.warn(`Backend report key "${reportKey}" not fully implemented for PostgreSQL. Applying generic filter if possible.`);
      rawData = []; 
  }
  
  return _applyGenericTextFilter(rawData, filters);
};

module.exports = { getReportData };