// backend/services/geminiServiceBackend.js
const { GoogleGenAI } = require('@google/genai');

const GEMINI_CHAT_MODEL_BACKEND = "gemini-2.5-flash-preview-04-17"; // Centralized model choice

const SYSTEM_INSTRUCTION_CHAT = `You are VisionBot, an AI assistant for Vision79 Shipment Inventory & Warehouse Manager. 
Your goal is to help users understand and navigate the application, provide information about logistics and warehouse management concepts, and offer suggestions based on simulated data if applicable. 
Keep responses concise and focused on the Vision79 SIWM context. 
If asked about a specific module like "Incoming Shipments", provide a brief overview of its purpose and key features (e.g., ASN processing, ETA tracking, AI delay prediction). 
If asked about "Inventory", talk about real-time levels, smart intake, and AI forecasting.
Be friendly and helpful. Do not answer general knowledge questions outside of this scope unless explicitly asked to do so as a demonstration.`;

let ai;
if (process.env.GEMINI_API_KEY) {
    try {
        ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    } catch (error) {
        console.error("Failed to initialize GoogleGenAI on backend:", error);
        ai = null;
    }
} else {
    console.warn("GEMINI_API_KEY for Gemini is not configured on the backend. AI features will be unavailable.");
    ai = null;
}

const getChatStream = async (userMessage, history) => {
    if (!ai) {
        throw new Error("AI service not available (backend configuration issue).");
    }
    
    const geminiHistory = history ? history.map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
    })) : [];

    const chat = ai.chats.create({
        model: GEMINI_CHAT_MODEL_BACKEND,
        config: {
            systemInstruction: SYSTEM_INSTRUCTION_CHAT,
        },
        history: geminiHistory,
    });

    return chat.sendMessageStream({ message: userMessage });
};

const generateText = async (prompt) => {
    if (!ai) {
        throw new Error("AI service not available (backend configuration issue).");
    }
    const response = await ai.models.generateContent({
        model: GEMINI_CHAT_MODEL_BACKEND, // Or a more specific model for text generation if needed
        contents: prompt,
    });
    return response.text;
};

const generateJson = async (prompt) => {
    if (!ai) {
        throw new Error("AI service not available (backend configuration issue).");
    }
    const response = await ai.models.generateContent({
        model: GEMINI_CHAT_MODEL_BACKEND, // Or a model fine-tuned for JSON
        contents: prompt,
        config: { responseMimeType: "application/json" }
    });
    
    // Log the raw AI response for debugging
    console.log("[GeminiService] Raw AI response:", response.text);
    
    // Parse and clean JSON as per guidelines
    let jsonStr = response.text.trim();
    // Fallback: Remove code block wrappers if present
    if (jsonStr.startsWith('```')) {
      jsonStr = jsonStr.replace(/^```[a-zA-Z0-9]*\s*/, '').replace(/```$/, '').trim();
    }
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    try {
      return JSON.parse(jsonStr);
    } catch (e) {
      console.error("Backend failed to parse JSON response from Gemini:", jsonStr, e);
      throw new Error("AI returned an invalid JSON format from backend.");
    }
};

const extractSerialsFromPdf = async (base64PdfData) => {
    if (!ai) {
        throw new Error("AI service not available (backend configuration issue).");
    }

    const pdfPart = {
        inlineData: {
            mimeType: 'application/pdf',
            data: base64PdfData,
        },
    };

    const textPart = {
        text: `Extract all unique serial numbers from the provided PDF document. Serial numbers are typically alphanumeric strings that can include hyphens. They are often listed in a column or table. List all found serial numbers in a flat JSON array of strings. Do not include any other text or explanation. If no serial numbers are found, return an empty array [].`
    };

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17",
        contents: { parts: [pdfPart, textPart] },
        config: { responseMimeType: "application/json" }
    });
    
    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    try {
      const parsed = JSON.parse(jsonStr);
      if (Array.isArray(parsed)) {
          return parsed.map(String).filter(Boolean); // ensure all elements are truthy strings
      }
      // If the AI returns a single object instead of an array (e.g., { "serials": [...] }), try to find the array.
      if(typeof parsed === 'object' && parsed !== null){
          const key = Object.keys(parsed).find(k => Array.isArray(parsed[k]));
          if(key) return parsed[key].map(String).filter(Boolean);
      }
      throw new Error("AI response was valid JSON but not an array of serials.");
    } catch (e) {
      console.error("Backend failed to parse JSON response from Gemini for PDF extraction:", jsonStr, e);
      throw new Error("AI returned an invalid JSON format.");
    }
};

module.exports = {
    getChatStream,
    generateText,
    generateJson,
    extractSerialsFromPdf,
};
