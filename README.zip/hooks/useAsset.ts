
// This file now acts as a clean re-export for the canonical useAsset hook.
export { useAsset } from '@/contexts/AssetContext';
