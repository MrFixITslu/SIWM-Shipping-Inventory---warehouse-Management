
// This file now acts as a clean re-export for the canonical useVendor hook.
export { useVendor } from '@/contexts/VendorContext';
