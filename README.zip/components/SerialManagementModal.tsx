import React, { useState, useEffect } from 'react';
import Modal from '@/components/Modal';
import { InventoryItem } from '@/types';
import { PlusIcon, DeleteIcon, SerialIcon } from '@/constants';

interface SerialManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: InventoryItem | null;
  onSaveSerials: (itemId: number, serials: string[]) => void;
}

const TAILWIND_INPUT_CLASSES = "shadow-sm appearance-none border border-secondary-300 bg-white text-secondary-900 rounded-md px-3 py-2 dark:border-secondary-600 dark:bg-secondary-700 dark:text-secondary-100 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500";

const SerialManagementModal: React.FC<SerialManagementModalProps> = ({ isOpen, onClose, item, onSaveSerials }) => {
  const [currentSerials, setCurrentSerials] = useState<string[]>([]);
  const [newSerial, setNewSerial] = useState<string>('');
  const [error, setError] = useState<string>('');

  useEffect(() => {
    if (item && item.isSerialized && item.serialNumbers) {
      setCurrentSerials([...item.serialNumbers]);
    } else {
      setCurrentSerials([]);
    }
    setNewSerial('');
    setError('');
  }, [item, isOpen]);

  if (!item) return null;

  const handleAddSerial = () => {
    if (!newSerial.trim()) {
      setError('Serial number cannot be empty.');
      return;
    }
    if (currentSerials.includes(newSerial.trim())) {
      setError('This serial number already exists for this item.');
      return;
    }
    setCurrentSerials([...currentSerials, newSerial.trim()]);
    setNewSerial('');
    setError('');
  };

  const handleDeleteSerial = (serialToDelete: string) => {
    setCurrentSerials(currentSerials.filter(s => s !== serialToDelete));
  };

  const handleSaveChanges = () => {
    onSaveSerials(item.id, currentSerials);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Manage Serials for ${item.name} (SKU: ${item.sku})`} size="lg">
      <div className="space-y-4">
        <div>
          <label htmlFor="newSerial" className="block text-sm font-medium text-secondary-700 dark:text-secondary-300">
            Add New Serial Number
          </label>
          <div className="mt-1 flex rounded-md shadow-sm">
            <input
              type="text"
              name="newSerial"
              id="newSerial"
              value={newSerial}
              onChange={(e) => {
                setNewSerial(e.target.value);
                if (error) setError('');
              }}
              placeholder="Enter serial number"
              className={`flex-1 min-w-0 block w-full px-3 py-2 rounded-none rounded-l-md ${TAILWIND_INPUT_CLASSES} focus:z-10 sm:text-sm`}
            />
            <button
              type="button"
              onClick={handleAddSerial}
              className="inline-flex items-center px-4 py-2 border border-l-0 border-primary-500 bg-primary-500 text-white rounded-r-md text-sm font-medium hover:bg-primary-600 focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
            >
              <PlusIcon className="h-5 w-5 mr-1 sm:mr-2" /> Add
            </button>
          </div>
          {error && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>}
        </div>

        {currentSerials.length > 0 ? (
          <div>
            <h4 className="text-md font-medium text-secondary-800 dark:text-secondary-200 mb-2">Registered Serial Numbers ({currentSerials.length})</h4>
            <div className="max-h-60 overflow-y-auto border border-secondary-200 dark:border-secondary-700 rounded-md p-2 space-y-2 bg-secondary-50 dark:bg-secondary-700/30">
              {currentSerials.map((serial) => (
                <div key={serial} className="flex items-center justify-between p-2 bg-white dark:bg-secondary-800 rounded-md">
                  <span className="flex items-center">
                    <SerialIcon className="h-4 w-4 mr-2 text-blue-500" />
                    {serial}
                  </span>
                  <button onClick={() => handleDeleteSerial(serial)} className="text-red-500 hover:text-red-700 p-1 rounded-full">
                    <DeleteIcon className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <p className="text-center text-secondary-500 dark:text-secondary-400 py-4">No serial numbers registered for this item yet.</p>
        )}

        <div className="flex justify-end space-x-3 pt-3">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-secondary-700 dark:text-secondary-300 bg-secondary-100 dark:bg-secondary-600 hover:bg-secondary-200 dark:hover:bg-secondary-500 rounded-md shadow-sm">
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSaveChanges}
            className="px-4 py-2 text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 rounded-md shadow-sm"
          >
            Save Changes
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default SerialManagementModal;
