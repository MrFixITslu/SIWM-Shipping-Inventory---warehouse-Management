import React, { useState, useMemo, useCallback, useEffect } from 'react';
import PageContainer from '@/components/PageContainer';
import Table from '@/components/Table';
import Modal from '@/components/Modal';
import ConfirmationModal from '@/components/ConfirmationModal';
import ErrorMessage from '@/components/ErrorMessage';
import SerialManagementModal from '@/components/SerialManagementModal';
import useConfirmationModal from '@/hooks/useConfirmationModal';
import { useInventory } from '@/hooks/useInventory';
import { useAuth } from '@/hooks/useAuth';
import { InventoryItem, ColumnDefinition } from '@/types';
import { PlusIcon, EditIcon, DeleteIcon, SearchIcon, SerialIcon } from '@/constants';
import { inventoryService } from '@/services/inventoryService';
import LoadingSpinner from '@/components/icons/LoadingSpinner';
import { debounce } from '@/utils/performance';

const TAILWIND_INPUT_CLASSES = "shadow-sm appearance-none border border-secondary-300 bg-white text-secondary-900 rounded-md px-3 py-2 dark:border-secondary-600 dark:bg-secondary-700 dark:text-secondary-100 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 text-sm";

const InventoryManagementPage: React.FC = () => {
  const { user } = useAuth();
  const {
    inventory,
    isLoading: isInventoryLoading,
    error: inventoryError,
    lastUpdatedId,
    clearLastUpdatedId,
  } = useInventory();

  const [highlightedRow, setHighlightedRow] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [currentItem, setCurrentItem] = useState<Partial<InventoryItem>>({});
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [isSerialModalOpen, setIsSerialModalOpen] = useState(false);
  const [selectedItemForSerials, setSelectedItemForSerials] = useState<InventoryItem | null>(null);

  const { isModalOpen: isConfirmDeleteOpen, confirmButtonText, showConfirmation, handleConfirm: handleConfirmDelete, handleClose: handleCloseDeleteConfirm } = useConfirmationModal();

  // Debounced search to improve performance
  const debouncedSetSearchTerm = useCallback(
    debounce((term: string) => {
      setDebouncedSearchTerm(term);
    }, 300),
    []
  );

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchTerm(value);
    debouncedSetSearchTerm(value);
  };

  useEffect(() => {
    if (lastUpdatedId) {
      setHighlightedRow(lastUpdatedId.id);
      const timer = setTimeout(() => {
        setHighlightedRow(null);
        clearLastUpdatedId();
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [lastUpdatedId, clearLastUpdatedId]);

  const filteredInventory = useMemo(() => {
    if (!debouncedSearchTerm.trim()) return inventory;
    const lower = debouncedSearchTerm.toLowerCase();
    return inventory.filter(item =>
      item.name?.toLowerCase().includes(lower) ||
      item.sku?.toLowerCase().includes(lower) ||
      item.category?.toLowerCase().includes(lower) ||
      item.location?.toLowerCase().includes(lower)
    );
  }, [inventory, debouncedSearchTerm]);

  const handleOpenItemModal = useCallback((item?: InventoryItem) => {
    setError(null);
    setCurrentItem(item || { isSerialized: false, quantity: 0, reorderPoint: 0 });
    setIsItemModalOpen(true);
  }, []);

  const handleCloseItemModal = () => {
    setIsItemModalOpen(false);
    setCurrentItem({});
    setError(null);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const isCheckbox = type === 'checkbox';
    
    if (isCheckbox && name === 'isSerialized') {
        const checked = (e.target as HTMLInputElement).checked;
        setCurrentItem(prev => {
            const newState: Partial<InventoryItem> = { ...prev, isSerialized: checked };
            if (checked) {
                // When becoming serialized, quantity is derived from serials. Reorder point is not applicable.
                newState.quantity = prev.serialNumbers?.length || 0;
                newState.reorderPoint = 0;
            } else {
                // When becoming non-serialized, quantity might be set to current serials length or a default
                newState.quantity = prev.serialNumbers?.length || 0;
            }
            return newState;
        });
    } else {
        const valueToSet = isCheckbox ? (e.target as HTMLInputElement).checked : value;
        setCurrentItem(prev => ({
            ...prev,
            [name]: valueToSet,
        }));
    }
  };

  const handleSaveItem = async () => {
    setError(null);
    setIsSaving(true);
    try {
      const itemToSave = {
        ...currentItem,
        quantity: currentItem.isSerialized ? currentItem.serialNumbers?.length || 0 : Number(currentItem.quantity || 0),
        reorderPoint: currentItem.isSerialized ? 0 : Number(currentItem.reorderPoint || 0),
        costPrice: Number(currentItem.costPrice || 0),
      };

      if (!itemToSave.name || !itemToSave.sku || !itemToSave.category || !itemToSave.location) {
        throw new Error('Name, SKU, Category, and Location are required fields.');
      }

      if (itemToSave.id) {
        await inventoryService.updateInventoryItem(itemToSave.id, itemToSave as InventoryItem);
      } else {
        await inventoryService.addInventoryItem(itemToSave as Omit<InventoryItem, 'id'>);
      }
      // No fetchInventory() call needed, context handles the update via SSE
      handleCloseItemModal();
    } catch (err: any) {
      let userFriendlyError = "An unexpected error occurred.";
      if (err.message) {
          if (err.message.toLowerCase().includes("failed to fetch")) {
              userFriendlyError = "Could not connect to the server. Please check your network or server status.";
          } else {
              userFriendlyError = err.message;
          }
      }
      setError(userFriendlyError);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteItem = useCallback((id: number) => {
    showConfirmation(async () => {
      setError(null);
      try {
        await inventoryService.deleteInventoryItem(id);
        // No fetchInventory() call needed, context handles the update via SSE
      } catch (err: any) {
        let userFriendlyError = "Failed to delete item.";
        if (err.message && err.message.toLowerCase().includes("failed to fetch")) {
          userFriendlyError = "Could not connect to server to delete item.";
        } else if (err.message) {
          userFriendlyError = err.message;
        }
        setError(userFriendlyError);
      }
    }, { confirmText: 'Confirm Delete' });
  }, [showConfirmation]);

  const handleOpenSerialModal = useCallback((item: InventoryItem) => {
    setSelectedItemForSerials(item);
    setIsSerialModalOpen(true);
  }, []);

  const handleCloseSerialModal = () => {
    setIsSerialModalOpen(false);
    setSelectedItemForSerials(null);
  };

  const handleSaveSerials = async (itemId: number, serials: string[]) => {
    try {
      await inventoryService.manageItemSerials(itemId, serials);
      // No fetchInventory() call needed, context handles the update via SSE
    } catch (err: any)
    {
      alert(`Error saving serials: ${err.message}`);
    }
  };

  const renderTableActions = useCallback((item: InventoryItem) => (
    <div className="flex space-x-1">
      {item.isSerialized && (
        <button onClick={() => handleOpenSerialModal(item)} className="text-blue-600 hover:text-blue-800 p-1" title="Manage Serials">
          <SerialIcon className="h-5 w-5" />
        </button>
      )}
      <button onClick={() => handleOpenItemModal(item)} className="text-primary-600 hover:text-primary-800 p-1" title="Edit Item">
        <EditIcon className="h-5 w-5" />
      </button>
      {user?.role === 'admin' && (
        <button onClick={() => handleDeleteItem(item.id)} className="text-red-600 hover:text-red-800 p-1" title="Delete Item">
          <DeleteIcon className="h-5 w-5" />
        </button>
      )}
    </div>
  ), [user, handleOpenSerialModal, handleOpenItemModal, handleDeleteItem]);

  const columns: ColumnDefinition<InventoryItem, keyof InventoryItem>[] = useMemo(() => [
    { key: 'name', header: 'Item Name', sortable: true },
    { key: 'sku', header: 'SKU', sortable: true },
    { key: 'category', header: 'Category', sortable: true },
    { key: 'quantity', header: 'Quantity', sortable: true, render: (item) => item.isSerialized ? item.serialNumbers?.length || 0 : item.quantity },
    { key: 'location', header: 'Location', sortable: true },
    { key: 'reorderPoint', header: 'Reorder Point', sortable: true, render: (item) => item.isSerialized ? 'N/A' : item.reorderPoint },
  ], []);

  if (inventoryError) {
    return (
      <PageContainer title="Inventory Management">
        <div className="p-4 text-red-600 bg-red-100 rounded-md dark:bg-red-800/30 dark:text-red-300">
          Error loading inventory: {inventoryError}
        </div>
      </PageContainer>
    );
  }

  if (isInventoryLoading && (!inventory || inventory.length === 0)) {
    return (
      <PageContainer title="Inventory Management">
        <div className="flex justify-center items-center h-64">
          <LoadingSpinner className="w-12 h-12 text-primary-500" />
          <p className="ml-4 text-lg">Loading inventory...</p>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer
      title="Inventory Management"
      actions={
        <button
          onClick={() => handleOpenItemModal()}
          className="flex items-center bg-primary-500 hover:bg-primary-600 text-white font-semibold px-4 py-2 rounded-lg shadow-md"
        >
          <PlusIcon className="h-5 w-5 mr-2" />
          Add Item
        </button>
      }
    >
      <div className="mb-4">
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-secondary-400" />
          <input
            type="text"
            placeholder="Search inventory..."
            value={searchTerm}
            onChange={handleSearchChange}
            className={`${TAILWIND_INPUT_CLASSES} pl-10 w-full max-w-md`}
          />
        </div>
      </div>

      {error && <ErrorMessage message={error} />}

      <Table
        columns={columns}
        data={filteredInventory}
        actions={renderTableActions}
        rowClassName={(item) => 
          highlightedRow === item.id 
            ? 'bg-green-50 dark:bg-green-900/20 border-l-4 border-green-500' 
            : ''
        }
      />

      {/* Item Modal */}
      <Modal
        isOpen={isItemModalOpen}
        onClose={handleCloseItemModal}
        title={currentItem.id ? 'Edit Item' : 'Add New Item'}
        size="lg"
      >
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-secondary-700 dark:text-secondary-300 mb-1">
                Item Name *
              </label>
              <input
                type="text"
                name="name"
                value={currentItem.name || ''}
                onChange={handleInputChange}
                className={TAILWIND_INPUT_CLASSES}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-secondary-700 dark:text-secondary-300 mb-1">
                SKU *
              </label>
              <input
                type="text"
                name="sku"
                value={currentItem.sku || ''}
                onChange={handleInputChange}
                className={TAILWIND_INPUT_CLASSES}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-secondary-700 dark:text-secondary-300 mb-1">
                Category *
              </label>
              <input
                type="text"
                name="category"
                value={currentItem.category || ''}
                onChange={handleInputChange}
                className={TAILWIND_INPUT_CLASSES}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-secondary-700 dark:text-secondary-300 mb-1">
                Location *
              </label>
              <input
                type="text"
                name="location"
                value={currentItem.location || ''}
                onChange={handleInputChange}
                className={TAILWIND_INPUT_CLASSES}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-secondary-700 dark:text-secondary-300 mb-1">
                Cost Price
              </label>
              <input
                type="number"
                name="costPrice"
                value={currentItem.costPrice || ''}
                onChange={handleInputChange}
                className={TAILWIND_INPUT_CLASSES}
                step="0.01"
                min="0"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-secondary-700 dark:text-secondary-300 mb-1">
                {currentItem.isSerialized ? 'Serial Numbers Count' : 'Quantity'}
              </label>
              <input
                type="number"
                name="quantity"
                value={currentItem.isSerialized ? (currentItem.serialNumbers?.length || 0) : (currentItem.quantity || '')}
                onChange={handleInputChange}
                className={TAILWIND_INPUT_CLASSES}
                min="0"
                disabled={currentItem.isSerialized}
              />
            </div>
            {!currentItem.isSerialized && (
              <div>
                <label className="block text-sm font-medium text-secondary-700 dark:text-secondary-300 mb-1">
                  Reorder Point
                </label>
                <input
                  type="number"
                  name="reorderPoint"
                  value={currentItem.reorderPoint || ''}
                  onChange={handleInputChange}
                  className={TAILWIND_INPUT_CLASSES}
                  min="0"
                />
              </div>
            )}
          </div>
          
          <div className="flex items-center">
            <input
              type="checkbox"
              name="isSerialized"
              checked={currentItem.isSerialized || false}
              onChange={handleInputChange}
              className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-secondary-300 rounded"
            />
            <label className="ml-2 block text-sm text-secondary-700 dark:text-secondary-300">
              This item is serialized (tracked by individual serial numbers)
            </label>
          </div>
        </div>

        <div className="flex justify-end space-x-3 mt-6">
          <button
            onClick={handleCloseItemModal}
            className="px-4 py-2 text-secondary-700 bg-secondary-100 hover:bg-secondary-200 rounded-md transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSaveItem}
            disabled={isSaving}
            className="px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-md transition-colors disabled:opacity-50"
          >
            {isSaving ? 'Saving...' : 'Save Item'}
          </button>
        </div>
      </Modal>

      {/* Serial Management Modal */}
      {selectedItemForSerials && (
        <SerialManagementModal
          isOpen={isSerialModalOpen}
          onClose={handleCloseSerialModal}
          item={selectedItemForSerials}
          onSaveSerials={handleSaveSerials}
        />
      )}

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={isConfirmDeleteOpen}
        onClose={handleCloseDeleteConfirm}
        onConfirm={handleConfirmDelete}
        title="Confirm Delete"
        message="Are you sure you want to delete this item? This action cannot be undone."
        confirmButtonText={confirmButtonText}
      />
    </PageContainer>
  );
};

export default InventoryManagementPage;