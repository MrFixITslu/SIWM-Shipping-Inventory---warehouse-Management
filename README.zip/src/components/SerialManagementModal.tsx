
import React, { useState, useEffect, useRef } from 'react';
import Modal from '@/components/Modal';
import { InventoryItem } from '@/types';
import { PlusIcon, DeleteIcon, SerialIcon, UploadIcon } from '@/constants';
import LoadingSpinner from '@/components/icons/LoadingSpinner';
import { geminiService } from '@/services/geminiService';
import Papa from 'papaparse';

interface SerialManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: InventoryItem | null;
  onSaveSerials: (itemId: number, serials: string[]) => void;
}

const TAILWIND_INPUT_CLASSES = "shadow-sm appearance-none border border-secondary-300 bg-white text-secondary-900 rounded-md px-3 py-2 dark:border-secondary-600 dark:bg-secondary-700 dark:text-secondary-100 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500";

const SerialManagementModal: React.FC<SerialManagementModalProps> = ({ isOpen, onClose, item, onSaveSerials }) => {
  const [currentSerials, setCurrentSerials] = useState<string[]>([]);
  const [newSerial, setNewSerial] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (item && item.isSerialized && item.serialNumbers) {
      setCurrentSerials([...item.serialNumbers]);
    } else {
      setCurrentSerials([]);
    }
    setNewSerial('');
    setError('');
    setIsUploading(false);
  }, [item, isOpen]);

  if (!item) return null;

  const handleAddSerial = () => {
    if (!newSerial.trim()) {
      setError('Serial number cannot be empty.');
      return;
    }
    if (currentSerials.includes(newSerial.trim())) {
      setError('This serial number already exists for this item.');
      return;
    }
    setCurrentSerials([...currentSerials, newSerial.trim()]);
    setNewSerial('');
    setError('');
  };

  const handleDeleteSerial = (serialToDelete: string) => {
    setCurrentSerials(currentSerials.filter(s => s !== serialToDelete));
  };
  
  const handleSaveChanges = () => {
    onSaveSerials(item.id, currentSerials);
    onClose();
  };

  const parseCsv = (file: File): Promise<string[]> => {
    return new Promise((resolve, reject) => {
        Papa.parse(file, {
            complete: (results) => {
                const serials = results.data
                    .flat() // Handle multiple columns or just one
                    .map(s => String(s || '').trim())
                    .filter(Boolean);
                resolve(serials);
            },
            error: (error: any) => reject(new Error(`CSV parsing error: ${error.message}`)),
        });
    });
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setError('');

    try {
        let serials: string[] = [];
        if (file.type === 'text/csv' || file.name.endsWith('.csv')) {
            serials = await parseCsv(file);
        } else if (file.type === 'application/pdf') {
            serials = await geminiService.extractTextFromPdf(file);
        } else {
            throw new Error('Unsupported file type. Please upload a .csv or .pdf file.');
        }

        const uniqueSerials = [...new Set(serials)];
        setCurrentSerials(uniqueSerials);

    } catch (err: any) {
        setError(err.message);
    } finally {
        setIsUploading(false);
        if(fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Manage Serials for ${item.name} (SKU: ${item.sku})`} size="lg">
      <div className="space-y-4">
        <div className="p-3 bg-secondary-50 dark:bg-secondary-800/50 rounded-lg">
          <label htmlFor="newSerial" className="block text-sm font-medium text-secondary-700 dark:text-secondary-300">
            Add New Serial Number
          </label>
          <div className="mt-1 flex rounded-md shadow-sm">
            <input
              type="text"
              name="newSerial"
              id="newSerial"
              value={newSerial}
              onChange={(e) => { setNewSerial(e.target.value); if (error) setError(''); }}
              onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSerial())}
              placeholder="Enter serial number and press Add"
              className={`flex-1 min-w-0 block w-full px-3 py-2 rounded-none rounded-l-md ${TAILWIND_INPUT_CLASSES} focus:z-10 sm:text-sm`}
            />
            <button
              type="button"
              onClick={handleAddSerial}
              className="inline-flex items-center px-4 py-2 border border-l-0 border-primary-500 bg-primary-500 text-white rounded-r-md text-sm font-medium hover:bg-primary-600 focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
            >
              <PlusIcon className="h-5 w-5 mr-1 sm:mr-2" /> Add
            </button>
          </div>
          <div className="mt-4">
              <input type="file" ref={fileInputRef} style={{ display: 'none' }} accept=".csv,.pdf" onChange={handleFileSelect} />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="w-full inline-flex items-center justify-center px-4 py-2 border border-dashed border-secondary-400 dark:border-secondary-600 text-sm font-medium rounded-md text-secondary-700 dark:text-secondary-300 bg-white dark:bg-secondary-700 hover:bg-secondary-50 dark:hover:bg-secondary-600 disabled:opacity-50"
              >
                  <UploadIcon className="h-5 w-5 mr-2" />
                  {isUploading ? 'Processing...' : 'Batch Upload from CSV or PDF'}
              </button>
          </div>
           {error && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>}
        </div>

        {currentSerials.length > 0 ? (
          <div>
            <h4 className="text-md font-medium text-secondary-800 dark:text-secondary-200 mb-2">Registered Serial Numbers ({currentSerials.length})</h4>
            <div className="max-h-60 overflow-y-auto border border-secondary-200 dark:border-secondary-700 rounded-md p-2 space-y-2 bg-secondary-50 dark:bg-secondary-700/30">
              {currentSerials.map((serial) => (
                <div key={serial} className="flex items-center justify-between p-2 bg-white dark:bg-secondary-800 rounded-md">
                  <span className="flex items-center font-mono text-xs">
                    <SerialIcon className="h-4 w-4 mr-2 text-blue-500" />
                    {serial}
                  </span>
                  <button onClick={() => handleDeleteSerial(serial)} className="text-red-500 hover:text-red-700 p-1 rounded-full">
                    <DeleteIcon className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        ) : (
          !isUploading && <p className="text-center text-secondary-500 dark:text-secondary-400 py-4">No serial numbers registered for this item yet.</p>
        )}
        {isUploading && <div className="flex justify-center py-4"><LoadingSpinner className="h-6 w-6" /></div>}

        <div className="flex justify-end space-x-3 pt-3">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-secondary-700 dark:text-secondary-300 bg-secondary-100 dark:bg-secondary-600 hover:bg-secondary-200 dark:hover:bg-secondary-500 rounded-md shadow-sm">
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSaveChanges}
            className="px-4 py-2 text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 rounded-md shadow-sm"
          >
            Save Changes
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default SerialManagementModal;
