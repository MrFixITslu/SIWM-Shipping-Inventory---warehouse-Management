
// This file now acts as a clean re-export for the canonical useAuth hook.
export { useAuth } from '@/contexts/AuthContext';
